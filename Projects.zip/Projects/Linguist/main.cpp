#include <QApplication>
#include <QTranslator>

#include "Form.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QTranslator translator;

    translator.load("C:\\Users\\root\\Desktop\\Linguist\\fa_IR.qm");
    app.installTranslator(&translator);
    app.setLayoutDirection(Qt::RightToLeft);

    Form form;
    form.show();

    return app.exec();
}
