<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fa_IR">
<context>
    <name>Form</name>
    <message>
        <source>Titl:</source>
        <translation>عنوان</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>تایید</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>اطلاعات</translation>
    </message>
</context>
</TS>
