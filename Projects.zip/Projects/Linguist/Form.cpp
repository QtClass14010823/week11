#include "Form.h"

#include <QFileDialog>
#include <QMessageBox>
#include <QDebug>

Form::Form(QWidget *parent/* = Q_NULLPTR*/, Qt::WindowFlags f/* = Qt::WindowFlags()*/) :
    QWidget(parent, f)
{
    layout = new QGridLayout(this);
    lblTitle = new QLabel(tr("Title:"), this);
    editName = new QLineEdit(this);
    btnOk = new QPushButton(tr("OK"), this);

    layout->addWidget(lblTitle, 0, 0);
    layout->addWidget(editName, 0, 1);
    layout->addWidget(btnOk, 0, 2);

    this->setLayout(layout);

    connect(btnOk, &QPushButton::clicked, this, &Form::on_BtnOk_Clicked);
}

void Form::on_BtnOk_Clicked()
{
    QMessageBox::information(this, tr("Information"), QString("Hello!"));
}
