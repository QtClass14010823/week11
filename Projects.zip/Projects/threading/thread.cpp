#include <QApplication>
#include <QWidget>
#include <QThread>
#include <QHBoxLayout>
#include <QPushButton>
#include <QDebug>

class Worker : public QObject
{
    Q_OBJECT

public:
    Worker(QObject *parent = nullptr);
    ~Worker();

public slots:
    void doWork(const bool isEven);
};

Worker::Worker(QObject *parent) : QObject(parent)
{
}

Worker::~Worker()
{
}

void Worker::doWork(const bool isEven) {
    /* ... here is the expensive or blocking operation ... */
    for (int i = 0; i < 10; i++)
    {
        if (i % 2 == (isEven) ? 0 : 1)
            qDebug() << i;

        QThread::sleep(1);
    }
}

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(QWidget *parent = nullptr);
    ~Form();

signals:
    void startWork(bool isEven);

private slots:
    void onBtn1Clicked();
    void onBtn2Clicked();
    void onBtn3Clicked();
    void onThreadFinished();

private:
    QThread *workerThread;
    QHBoxLayout *layout;
    QPushButton *btn1, *btn2, *btn3;
    Worker *worker;
};

Form::Form(QWidget *parent) : QWidget(parent)
{
    workerThread = new QThread(this);
    worker = new Worker;
    worker->moveToThread(workerThread);
    layout = new QHBoxLayout(this);
    btn1 = new QPushButton("Counting odd numbers");
    btn2 = new QPushButton("Counting even numbers");
    btn3 = new QPushButton("Terminate");

    layout->addWidget(btn1);
    layout->addWidget(btn2);
    layout->addWidget(btn3);

    connect(btn1, &QPushButton::clicked, this, &Form::onBtn1Clicked);
    connect(btn2, &QPushButton::clicked, this, &Form::onBtn2Clicked);
    connect(btn3, &QPushButton::clicked, this, &Form::onBtn3Clicked);
    connect(this, &Form::startWork, worker, &Worker::doWork, Qt::QueuedConnection);
    //connect(this, &Form::startWork, worker, &Worker::doWork, Qt::BlockingQueuedConnection);
    connect(workerThread, &QThread::finished, worker, &QObject::deleteLater, Qt::AutoConnection);

    workerThread->start();
}

Form::~Form()
{
    if (workerThread->isRunning())
    {
        workerThread->quit();
        workerThread->wait();
    }

    //delete worker; // this is wrong, because if thread is terminated delete causes crash.
    //delete workerThread; // Enable when "workerThread = new QThread;"
}

void Form::onBtn1Clicked()
{
    emit startWork(false);
}

void Form::onBtn2Clicked()
{
    emit startWork(true);
}

void Form::onBtn3Clicked()
{
    if (workerThread->isRunning())
    {
        workerThread->terminate();
        workerThread->wait();
    }
}

void Form::onThreadFinished()
{
    worker->deleteLater();
}

#include "main.moc"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form frm;

    frm.show();
    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QWidget>
#include <QThread>
#include <QHBoxLayout>
#include <QPushButton>
#include <QDebug>

class Worker : public QObject
{
    Q_OBJECT

public:
    Worker(QObject *parent = nullptr);
    ~Worker();

public slots:
    void doWork(const bool isEven);
};

Worker::Worker(QObject *parent) : QObject(parent)
{
}

Worker::~Worker()
{
}

void Worker::doWork(const bool isEven) {
    /* ... here is the expensive or blocking operation ... */
    for (int i = 0; i < 10; i++)
    {
        if (i % 2 == (isEven) ? 0 : 1)
            qDebug() << i;

        QThread::sleep(1);
    }
}

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtn1Clicked();
    void onBtn2Clicked();
    void onBtn3Clicked();
    void onThreadFinished();

private:
    QThread *workerThread;
    QHBoxLayout *layout;
    QPushButton *btn1, *btn2, *btn3;
    Worker *worker;
};

Form::Form(QWidget *parent) : QWidget(parent)
{
    workerThread = new QThread(this);
    worker = new Worker;
    worker->moveToThread(workerThread);
    layout = new QHBoxLayout(this);
    btn1 = new QPushButton("Counting odd numbers");
    btn2 = new QPushButton("Counting even numbers");
    btn3 = new QPushButton("Terminate");

    layout->addWidget(btn1);
    layout->addWidget(btn2);
    layout->addWidget(btn3);

    connect(btn1, &QPushButton::clicked, this, &Form::onBtn1Clicked);
    connect(btn2, &QPushButton::clicked, this, &Form::onBtn2Clicked);
    connect(btn3, &QPushButton::clicked, this, &Form::onBtn3Clicked);
    //connect(this, &Form::startWork, worker, &Worker::doWork, Qt::BlockingQueuedConnection);
    connect(workerThread, &QThread::finished, worker, &QObject::deleteLater, Qt::AutoConnection);

    workerThread->start();
}

Form::~Form()
{
    if (workerThread->isRunning())
    {
        workerThread->quit();
        workerThread->wait();
    }

    //delete worker; // this is wrong, because if thread is terminated delete causes crash.
    //delete workerThread; // Enable when "workerThread = new QThread;"
}

void Form::onBtn1Clicked()
{
    QMetaObject::invokeMethod(worker, "doWork", Qt::AutoConnection, Q_ARG(bool, false));
}

void Form::onBtn2Clicked()
{
    QMetaObject::invokeMethod(worker, "doWork", Qt::AutoConnection, Q_ARG(bool, true));
}

void Form::onBtn3Clicked()
{
    if (workerThread->isRunning())
    {
        workerThread->terminate();
        workerThread->wait();
    }
}

void Form::onThreadFinished()
{
    worker->deleteLater();
}

#include "main.moc"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form frm;

    frm.show();
    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QWidget>
#include <QThread>
#include <QHBoxLayout>
#include <QPushButton>
#include <QDebug>

class WorkerThread : public QThread
{
    Q_OBJECT

public:
    WorkerThread(QObject *parent = nullptr) : QThread(parent)
    {
    }

protected:
    void run() Q_DECL_OVERRIDE {
        /* ... here is the expensive or blocking operation ... */
        for (int i = 0; i < 10; i++)
        {
            qDebug() << i;

            QThread::sleep(1);
        }
    }

signals:
};

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtn1Clicked();
    void onBtn2Clicked();
    void onThreadFinished();

private:
    WorkerThread *workerThread;
    QHBoxLayout *layout;
    QPushButton *btn1, *btn2;
};

Form::Form(QWidget *parent) : QWidget(parent)
{
    workerThread = new WorkerThread(this);
    layout = new QHBoxLayout(this);
    btn1 = new QPushButton("Counting numbers");
    btn2 = new QPushButton("Terminate");

    layout->addWidget(btn1);
    layout->addWidget(btn2);

    connect(btn1, &QPushButton::clicked, this, &Form::onBtn1Clicked);
    connect(btn2, &QPushButton::clicked, this, &Form::onBtn2Clicked);
    connect(workerThread, &WorkerThread::finished, this, &Form::onThreadFinished);
}

Form::~Form()
{
    if (workerThread->isRunning())
    {
        workerThread->wait();
        //workerThread->terminate();
    }

    delete workerThread; // Enable when "workerThread = new QThread;"
}

void Form::onBtn1Clicked()
{
    workerThread->start();
}

void Form::onBtn2Clicked()
{
    if (workerThread->isRunning())
    {
        workerThread->terminate();
    }
}

void Form::onThreadFinished()
{
}

#include "main.moc"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form frm;

    frm.show();
    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QWidget>
#include <QThreadPool>
#include <QRunnable>
#include <QHBoxLayout>
#include <QPushButton>
#include <QDebug>

class MyTask : public QRunnable
{
    void run() override
    {
        /* ... here is the expensive or blocking operation ... */
        for (int i = 0; i < 10; i++)
        {
            qDebug() << i;

            QThread::sleep(1);
        }
    }
};

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtn1Clicked();
    void onBtn2Clicked();

private:
    MyTask *task;
    QHBoxLayout *layout;
    QPushButton *btn1, *btn2;
};

Form::Form(QWidget *parent) : QWidget(parent)
{
    layout = new QHBoxLayout(this);
    btn1 = new QPushButton("Counting numbers");
    btn2 = new QPushButton("Terminate");

    layout->addWidget(btn1);
    layout->addWidget(btn2);

    connect(btn1, &QPushButton::clicked, this, &Form::onBtn1Clicked);
    connect(btn2, &QPushButton::clicked, this, &Form::onBtn2Clicked);
}

Form::~Form()
{
}

void Form::onBtn1Clicked()
{
    task = new MyTask;
    // QThreadPool takes ownership and deletes 'hello' automatically
    QThreadPool::globalInstance()->start(task);
}

void Form::onBtn2Clicked()
{
}

#include "main.moc"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form frm;

    frm.show();
    return a.exec();
}
-------------------------------
#include <QApplication>
#include <QWidget>
#include <QThreadPool>
#include <QRunnable>
#include <QHBoxLayout>
#include <QPushButton>
#include <QDebug>

class MyTask : public QRunnable
{
    void run() override
    {
        /* ... here is the expensive or blocking operation ... */
        for (int i = 0; i < 10; i++)
        {
            qDebug() << i;

            QThread::sleep(1);
        }
    }
};

class Form : public QWidget
{
    Q_OBJECT

public:
    Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtn1Clicked();
    void onBtn2Clicked();

private:
    MyTask *task;
    QHBoxLayout *layout;
    QPushButton *btn1, *btn2;
};

Form::Form(QWidget *parent) : QWidget(parent)
{
    layout = new QHBoxLayout(this);
    btn1 = new QPushButton("Counting numbers");
    btn2 = new QPushButton("Terminate");

    layout->addWidget(btn1);
    layout->addWidget(btn2);

    connect(btn1, &QPushButton::clicked, this, &Form::onBtn1Clicked);
    connect(btn2, &QPushButton::clicked, this, &Form::onBtn2Clicked);
}

Form::~Form()
{
}

void Form::onBtn1Clicked()
{
    task = new MyTask;
    // QThreadPool takes ownership and deletes 'hello' automatically
    QThreadPool::globalInstance()->start(task);
}

void Form::onBtn2Clicked()
{
	QThreadPool::globalInstance()->waitForDone();
}

#include "main.moc"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Form frm;

    frm.show();
    return a.exec();
}