#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QThread>
#include <QHBoxLayout>
#include <QPushButton>

#include "worker.h"

class Form : public QWidget
{
    Q_OBJECT
public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

signals:
    void startWork(bool isEven);

private slots:
    void onBtn1Clicked();

private:
    QThread *workerThread;
    QHBoxLayout *layout;
    QPushButton *btn1, *btn2, *btn3;
    Worker *worker;
};

#endif // FORM_H
