#include "Form.h"

#include <QFile>
#include <QFileDialog>
#include <QMessageBox>

Form::Form(QWidget *parent) : QWidget(parent)
{
    bLayout = new QGridLayout(this);
    lblSrc = new QLabel("Source file:", this);
    lblDst = new QLabel("Destination file:", this);
    lnEditSrc = new QLineEdit(this);
    lnEditDst = new QLineEdit(this);
    btnSrcFile = new QPushButton("...", this);
    btnDstFile = new QPushButton("...", this);
    btnCopy = new QPushButton("Copy", this);

    bLayout->addWidget(lblSrc, 0, 0);
    bLayout->addWidget(lblDst, 1, 0);
    bLayout->addWidget(lnEditSrc, 0, 1);
    bLayout->addWidget(lnEditDst, 1, 1);
    bLayout->addWidget(btnSrcFile, 0, 2);
    bLayout->addWidget(btnDstFile, 1, 2);
    bLayout->addWidget(btnCopy, 3, 0, 1, 3);
    this->setLayout(bLayout);

    this->setWindowTitle("File copy project");
    connect(btnSrcFile, &QPushButton::clicked, this, &Form::onSrcClicked);
    connect(btnDstFile, &QPushButton::clicked, this, &Form::onDstClicked);
    connect(btnCopy, &QPushButton::clicked, this, &Form::onCopyClicked);
}

void Form::onSrcClicked()
{
    QString file1Name = QFileDialog::getOpenFileName(this,
             "Select source file", "/home", tr("All Files (*.*)"));

    lnEditSrc->setText(file1Name);
}

void Form::onDstClicked()
{
    QString file1Name = QFileDialog::getSaveFileName(this,
             "Select destination file", "/home", tr("All Files (*.*)"));

    lnEditDst->setText(file1Name);
}

void Form::onCopyClicked()
{
    QFile in(lnEditSrc->text());
    QFile out(lnEditDst->text());
    char buff[100];
    quint64 readLen = 0;
    quint64 totalReadLen = 0;
    int percentage = 0;

    in.open(QIODevice::ReadOnly);
    out.open(QIODevice::WriteOnly);

    this->setWindowTitle(QString("Copying 0%"));

    while(!in.atEnd())
    {
        readLen = in.read(buff, sizeof(buff));
        totalReadLen += readLen;

        if (readLen > 0)
        {
            out.write(buff, readLen);
            percentage = (float)totalReadLen / (float)in.size() * 100;
            this->setWindowTitle(QString("Copying %0%1").arg(percentage).arg("%"));
        }
    }

    out.close();
    in.close();

    this->setWindowTitle("File copy project");
    QMessageBox::information(this, "Information", "Copy complete.");
}
