#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QGridLayout>
#include <QPushButton>
#include <QFuture>
#include <QFutureWatcher>

QStringList StartGlobalWork(QString str);

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

signals:

private slots:
    void onBtnStartWorkClicked();
    void onBtnStartGlobalWorkClicked();
    void onBtnStartAsyncGlobalWorkClicked();
    void onAsyncGlobalWorkFinished();
    void onBtnRunLambdaFunction();

private:
    QGridLayout *layout;
    QPushButton *btnStartWork, *btnStartGlobalWork;
    QPushButton *btnStartAsyncGlobalWork, *btnRunLambdaFunction;
    QFutureWatcher<QStringList> watcher;

    void startWork(const bool isEven);
};

#endif // FORM_H
