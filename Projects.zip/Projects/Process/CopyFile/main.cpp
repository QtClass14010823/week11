#include <QCoreApplication>

#include <iostream>

#include <QFile>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    QStringList args = QCoreApplication::arguments();

    if (args.count() != 3)
    {
        std::cerr << "The number of parameters is invalid!";
        return 1;
    }
    else
    {
        QFile::copy(args.at(1), args.at(2));
        std::cout << "Copy done.";
    }

    return 0;
}
