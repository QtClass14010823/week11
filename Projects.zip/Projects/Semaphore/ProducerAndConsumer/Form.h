#ifndef FORM_H
#define FORM_H

#include <QWidget>
#include <QGridLayout>
#include <QPushButton>
#include <QProgressBar>

#include "Producer.h"
#include "Consumer.h"

class Form : public QWidget
{
    Q_OBJECT

public:
    explicit Form(QWidget *parent = nullptr);
    ~Form();

public slots:
    void onBufferValueChanged(int);
    void onProducerValueChanged(int);
    void onConsumerValueChanged(int);

signals:

private slots:
    void onBtnStartClicked();

private:
    QGridLayout *layout;
    QProgressBar *producerProgressBar;
    QProgressBar *consumerProgressBar;
    QProgressBar *bufferProgressBar;
    QPushButton *btnStart;
    Producer *mProducer;
    Consumer *mConsumer;
};

#endif // FORM_H
