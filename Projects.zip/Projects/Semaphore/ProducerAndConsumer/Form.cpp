#include "Form.h"

#include <QDebug>

#include "Common.h"

Form::Form(QWidget *parent) : QWidget(parent)
{
    layout = new QGridLayout(this);
    producerProgressBar = new QProgressBar;
    consumerProgressBar = new QProgressBar;
    bufferProgressBar = new QProgressBar;
    btnStart = new QPushButton("Start");

    layout->addWidget(producerProgressBar, 0, 0);
    layout->addWidget(consumerProgressBar, 1, 0);
    layout->addWidget(bufferProgressBar, 2, 0);
    layout->addWidget(btnStart, 3, 0, 1, 2);

    // progress bar range setup
    producerProgressBar->setRange(0, DataSize - 1);
    consumerProgressBar->setRange(0, DataSize - 1);
    bufferProgressBar->setRange(0, BufferSize - 1);

    // make two threads
    mProducer = new Producer(this);
    mConsumer = new Consumer(this);

    // connect signal/slot for the buffer progress bar
    connect(mConsumer, SIGNAL(bufferFillCountChanged(int)),
              this, SLOT(onBufferValueChanged(int)));
    connect(mProducer, SIGNAL(bufferFillCountChanged(int)),
              this, SLOT(onBufferValueChanged(int)));

    // connect signal/slot for consumer/producer progress bar
    connect(mConsumer, SIGNAL(consumerCountChanged(int)),
              this, SLOT(onConsumerValueChanged(int)));
    connect(mProducer, SIGNAL(producerCountChanged(int)),
              this, SLOT(onProducerValueChanged(int)));

    connect(btnStart, &QPushButton::clicked, this, &Form::onBtnStartClicked);
}

Form::~Form()
{
}

void Form::onBufferValueChanged(int bCount)
{
    bufferProgressBar->setValue(bCount);
}

void Form::onProducerValueChanged(int pCount)
{
    producerProgressBar->setValue(pCount);
}

void Form::onConsumerValueChanged(int cCount)
{
    consumerProgressBar->setValue(cCount);
}

void Form::onBtnStartClicked()
{
    // disable the start button
    btnStart->setEnabled(false);

    // threads starat
    mProducer->start();
    mConsumer->start();
}

